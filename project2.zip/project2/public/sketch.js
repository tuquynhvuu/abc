let mappa = new Mappa('Leaflet'); 
let myMap;
let canvas;
let currentLongitude = 0; 
let currentLatitude = 0; 
let mapInit = false; 
let me; 

let playerName = "";
let teamColor = "";
let joinedTeam = false;

// Track teammates
let teammates = {}; // { socketId: {name, lat, lon} }

if(location.hostname.toLowerCase().startsWith('browsercircus')){
  socket = io({path: "/YOURPATH-and-PORT/socket.io"});  
}else{
  socket = io(); 
}

// Map options
let mappa_options = {
  lat: 0,
  lng: 0,
  zoom: 16,
  style: 'https://webst01.is.autonavi.com/appmaptile?lang=zh_cn&size=1&scale=1&style=6&x={x}&y={y}&z={z}',
}

function setup() {
  canvas = createCanvas(windowWidth, windowHeight);
  canvas.parent("p5-canvas-container");
  me = new MyPoint();

  // TEAM JOIN LOGIC
  document.getElementById("joinTeamButton").addEventListener("click", () => {
    const nameInput = document.getElementById("playerName").value.trim();
    const teamInput = document.getElementById("teamSelect").value;

    if(nameInput === ""){
      alert("Please enter your name!");
      return;
    }

    playerName = nameInput;
    teamColor = teamInput;
    joinedTeam = true;

    document.getElementById("team-join-container").style.display = "none";

    socket.emit("playerJoin", { name: playerName, team: teamColor });
  });

  // Receive teammates update from server
  socket.on("playersUpdate", (players) => {
    if(!joinedTeam) return;
    teammates = {};
    for(let id in players){
      if(players[id].team === teamColor){
        teammates[id] = players[id];
      }
    }
    updateTeamDisplay();
  });
}

// Show team banner
function updateTeamDisplay(){
  if(!joinedTeam) return;

  const teamDisplay = document.getElementById("team-display");
  teamDisplay.style.display = "flex";
  teamDisplay.style.backgroundColor = teamColor;

  const nameSpan = document.getElementById("my-team-name");
  const membersSpan = document.getElementById("team-members");

  let names = [];
  for(let id in teammates){
    names.push(teammates[id].name);
  }

  nameSpan.innerText = `Team ${capitalize(teamColor)}: `;
  membersSpan.innerText = names.join(", ");
}

function capitalize(str){
  return str.charAt(0).toUpperCase() + str.slice(1);
}

function draw() {
  clear();

  if(!mapInit && GPS_GRANTED && currentLongitude != 0){
    mappa_options.lat = currentLatitude;
    mappa_options.lng = currentLongitude;
    myMap = mappa.tileMap(mappa_options); 
    myMap.overlay(canvas);
    myMap.onChange(updateMapContent);
    mapInit = true;
  }

  if(mapInit){
    me.update();
    me.display();

    // Draw teammates only
    for(let id in teammates){
      const player = teammates[id];
      if(player.lat && player.lon){
        let pos = myMap.latLngToPixel(player.lat, player.lon);
        fill(player.team);
        stroke("black");
        strokeWeight(2);
        circle(pos.x, pos.y, 20);

        noStroke();
        fill("black");
        textAlign(CENTER);
        text(player.name, pos.x, pos.y - 15);
      }
    }
  }
}

// P5 touch events
function touchStarted() {}
function touchMoved() {}
function touchEnded() {}
function windowResized(){ resizeCanvas(windowWidth, windowHeight); }

function handleNewPosition(pos){
  let lonlat = fixForChineseMap(pos);
  currentLongitude = lonlat[0];
  currentLatitude = lonlat[1];

  if(mapInit) updateMapContent();

  if(joinedTeam){
    socket.emit("playerPosition", {lat: currentLatitude, lon: currentLongitude});
  }
}

function updateMapContent(){
  let myPosOnCanvas = myMap.latLngToPixel(currentLatitude, currentLatitude)
  me.goalX = myPosOnCanvas.x;
  me.goalY = myPosOnCanvas.y;
}

class MyPoint{
  constructor(){
    this.x = 0;
    this.y = 0;
    this.goalX = 0;
    this.goalY = 0;
    this.size = 14;
    this.col = color(170, 240, 190);
  }
  update(){
    this.x = lerp(this.x, this.goalX, 0.2)
    this.y = lerp(this.y, this.goalY, 0.2)
  }
  display(){
    push();
    translate(this.x, this.y);
    fill(this.col);
    stroke("pink");
    strokeWeight(3)
    let dia = this.size + sin(frameCount*0.1)
    circle(0, 0, dia);
    pop();
  }
}
